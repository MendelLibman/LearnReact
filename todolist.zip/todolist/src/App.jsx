import "./App.css";
import Container from "./Components/Container/Container";
const App = () => {
  return (
    <div className="container">
      <Container />
    </div>
  );
};

export default App;
