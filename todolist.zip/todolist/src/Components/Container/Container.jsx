import { useState } from "react";

import Tasks from "../Tasks/Tasks";
import AddTask from "../Forms/AddTask/AddTask";
import "./Container.css";

const Container = () => {
  const [tasks, setTasks] = useState([]);

  const createId = () => {
    const timestamp = Date.now();
    const prefix = "task";
    const newId = `${prefix}-${timestamp}`;
    return newId;
  };
  const handleSubmit = (data) => {
    // TODO: Validation
    const newTask = {
      ...data,
      id: createId(),
    };
    setTasks([...tasks, newTask]);
  };
  const handleDelete = (idToDelete) => {
    const updatedTasks = tasks.filter((task) => task.id !== idToDelete);
    setTasks(updatedTasks);
  };
  const handleEdit = (idToEdit, newContent) => {
    const updatedTasks = [...tasks];
    if (idToEdit) {
      setTasks(
        updatedTasks.map((task) => {
          if (task.id === idToEdit) {
            return { ...task, content: newContent };
          }
          return task;
        })
      );
    } else {
      console.error("Task not found for editing");
    }
  };

  return (
    <>
      <h1>Plan your next move</h1>
      <div>
        <AddTask onSubmit={handleSubmit} />
        <Tasks tasks={tasks} onEdit={handleEdit} onDelete={handleDelete} />
      </div>
    </>
  );
};

export default Container;
