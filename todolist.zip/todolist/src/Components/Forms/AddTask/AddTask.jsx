import { useForm } from "react-hook-form";
import PropTypes from "prop-types";
import "./AddTask.css";

const propTypes = {
  onSubmit: PropTypes.func,
};

const AddTask = (props) => {
  const { onSubmit } = props;
  const { register, handleSubmit, reset } = useForm();

  const SubmitWithReset = (data) => {
    onSubmit(data);
    reset();
  };

  return (
    <div className="form-add">
      <form onSubmit={handleSubmit(SubmitWithReset)}>
        <input
          type="text"
          name="task"
          placeholder="Enter task"
          {...register("content", { required: true })}
          autoComplete="off" // Add this attribute
        />
        <button className="add-btn" type="submit">
          Add
        </button>
      </form>
    </div>
  );
};

AddTask.propTypes = propTypes;

export default AddTask;
