import { useState } from "react";
import PropTypes from "prop-types";

import './EditTask.css';

const propTypes = {
  task: PropTypes.object,
  onEdit: PropTypes.func,
  onCancel: PropTypes.func,
};

const EditTask = (props) => {
  const { task, onEdit, onCancel } = props;
  const [editedContent, setEditedContent] = useState(task.content);

  const handleContentChange = (event) => {
    setEditedContent(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    onEdit(editedContent);
  };

  return (
    <div className="edit-form">
    <form onSubmit={handleSubmit}>
      <input className="edit-input" type="text" value={editedContent} onChange={handleContentChange} />
      <button className="save-btn" type="submit">Save</button>
      <button className="cancel-btn" type="button" onClick={onCancel}>
        Cancel
      </button>
    </form>
    </div>
  );
};

EditTask.propTypes = propTypes;

export default EditTask;
