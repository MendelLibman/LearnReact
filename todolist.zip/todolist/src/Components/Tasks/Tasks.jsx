import { useState } from "react";
import PropTypes from "prop-types";
import EditTask from "../Forms/EditTask/EditTask";
import './Tasks.css'

const propTypes = {
  tasks: PropTypes.array,
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
};

const Tasks = (props) => {
  const { tasks, onEdit, onDelete } = props;
  const [editingTaskId, setEditingTaskId] = useState(null);

  const handleEdit = (taskId) => {
    setEditingTaskId(taskId);
  };

  const handleCancel = () => {
    setEditingTaskId(null);
  };

  return (
    <div>
      <ul className="list">
        {tasks.map((task) => (
          <li className="list-item" key={task.id}>
            {editingTaskId === task.id ? (
              <EditTask
                task={task}
                onCancel={handleCancel}
                onEdit={(newContent) => {
                  onEdit(task.id, newContent);
                  setEditingTaskId(null);
                }}
              />
            ) : (
              <>
                <label>{task.content}</label>
                <div>
                <button className="delete-btn" onClick={() => onDelete(task.id)}>Delete</button>
                <button className="edit-btn" onClick={() => handleEdit(task.id)}>Edit</button>
                </div>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

Tasks.propTypes = propTypes;

export default Tasks;
